export const proUrl = 'https://safeedu.bnasafe.com' //在线请求地址
export const devUrl = 'http://192.168.0.26:8189'  //本地请求地址