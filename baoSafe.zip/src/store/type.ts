// pinia参数格式
export interface userInfo {
    assistCompany: string,
    baoDepartment: number,
    baoFactory: number,
    icCardWorkNumber: string,
    id: number,
    manageArea: string,
    recentJob: string,
    userAuth: number,
    userType: number,
    username: string
}