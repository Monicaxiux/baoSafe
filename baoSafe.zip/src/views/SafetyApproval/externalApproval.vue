<template>
    年度安全教育审批
</template>
<script lang="ts" setup>

</script>
<style scoped>
</style>