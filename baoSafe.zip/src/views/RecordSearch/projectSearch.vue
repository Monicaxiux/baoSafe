<template>
    施工记录查询
</template>
<script lang="ts" setup>

</script>
<style scoped>
</style>