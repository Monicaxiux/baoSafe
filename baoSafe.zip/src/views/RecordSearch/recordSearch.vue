<template>
    人员登记查询
</template>
<script lang="ts" setup>

</script>
<style scoped>
</style>